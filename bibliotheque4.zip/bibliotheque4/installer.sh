#installer.sh - Script d'Installation
#!/bin/bash

################################################################################
# SCRIPT D'INSTALLATION - SYSTÈME DE GESTION DE BIBLIOTHÈQUE
# Facilite l'installation et la configuration initiale
################################################################################

set -e

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                                                            ║"
echo "║        📚 INSTALLATION - GESTION BIBLIOTHÈQUE 📚           ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# Vérifier que nous sommes dans le bon dossier
if [[ ! -f "bibliotheque.sh" ]] || [[ ! -f "lib_functions.sh" ]]; then
    echo -e "${RED}❌ Erreur: Fichiers manquants!${NC}"
    echo "Assurez-vous d'être dans le dossier contenant:"
    echo "  - bibliotheque.sh"
    echo "  - lib_functions.sh"
    echo "  - generer_donnees_test.sh"
    exit 1
fi

echo -e "${GREEN}✓ Fichiers du projet détectés${NC}"
echo ""

# Vérifier Bash version
BASH_VERSION_MAJOR=${BASH_VERSION:0:1}
if [[ $BASH_VERSION_MAJOR -lt 4 ]]; then
    echo -e "${YELLOW}⚠️  Avertissement: Bash version < 4.0 détectée${NC}"
    echo "Certaines fonctionnalités pourraient ne pas fonctionner correctement."
    echo "Version actuelle: $BASH_VERSION"
    echo ""
    read -p "Continuer quand même? (o/n): " continue_install
    if [[ "$continue_install" != "o" ]]; then
        exit 1
    fi
else
    echo -e "${GREEN}✓ Version de Bash compatible: $BASH_VERSION${NC}"
fi
echo ""

# Vérifier les dépendances
echo "Vérification des dépendances..."
MISSING_DEPS=()

for cmd in grep awk sed sort uniq tar date; do
    if ! command -v $cmd &> /dev/null; then
        MISSING_DEPS+=("$cmd")
    fi
done

if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
    echo -e "${RED}❌ Commandes manquantes: ${MISSING_DEPS[*]}${NC}"
    echo "Veuillez installer ces commandes avant de continuer."
    exit 1
else
    echo -e "${GREEN}✓ Toutes les dépendances sont installées${NC}"
fi
echo ""

# Vérifier les commandes optionnelles
echo "Vérification des fonctionnalités optionnelles..."

if command -v chromium &> /dev/null; then
    echo -e "${GREEN}✓ chromium installé (conversion PDF disponible)${NC}"
else
    echo -e "${YELLOW}⚠️  chromium non installé (conversion PDF manuelle uniquement)${NC}"
    echo "   Pour l'installer:"
    echo "   - Linux: sudo apt-get install chromium"
    echo "   - macOS: brew install chromium"
fi

if command -v weasyprint &> /dev/null; then
    echo -e "${GREEN}✓ weasyprint installé (conversion PDF disponible)${NC}"
else
    echo -e "${YELLOW}⚠️  weasyprint non installé (conversion PDF manuelle uniquement)${NC}"
    echo "   Pour l'installer:"
    echo "   - Linux: sudo apt-get install weasyprint"
    echo "   - macOS: brew install weasyprint"
fi

if command -v xdg-open &> /dev/null || command -v open &> /dev/null; then
    echo -e "${GREEN}✓ Ouverture automatique de fichiers disponible${NC}"
else
    echo -e "${YELLOW}⚠️  Ouverture automatique de fichiers non disponible${NC}"
fi
echo ""

# Rendre les scripts exécutables
echo "Configuration des permissions..."
chmod +x bibliotheque.sh
chmod +x lib_functions.sh
[[ -f generer_donnees_test.sh ]] && chmod +x generer_donnees_test.sh
echo -e "${GREEN}✓ Permissions configurées${NC}"
echo ""

# Créer la structure de dossiers
echo "Création de la structure de dossiers..."
mkdir -p data backups exports
echo -e "${GREEN}✓ Dossiers créés: data/, backups/, exports/${NC}"
echo ""

# Proposer de générer des données de test
if [[ -f generer_donnees_test.sh ]]; then
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    read -p "Voulez-vous générer des données de test? (o/n): " gen_test
    
    if [[ "$gen_test" == "o" ]] || [[ "$gen_test" == "O" ]]; then
        echo ""
        bash ./generer_donnees_test.sh
    else
        echo ""
        echo "Création des fichiers vides..."
        
        if [[ ! -f data/livres.txt ]]; then
            echo "# ID|Titre|Auteur|Année|Genre|Statut" > data/livres.txt
            echo -e "${GREEN}✓ data/livres.txt créé${NC}"
        fi
        
        if [[ ! -f data/emprunts.txt ]]; then
            echo "# ID_Livre|Emprunteur|Date_Emprunt|Date_Retour_Prévue|Statut" > data/emprunts.txt
            echo -e "${GREEN}✓ data/emprunts.txt créé${NC}"
        fi
    fi
fi

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}✅ INSTALLATION TERMINÉE AVEC SUCCÈS!${NC}"
echo ""
echo "Structure créée:"
echo "  📁 data/         - Données de la bibliothèque"
echo "  📁 backups/      - Sauvegardes automatiques et manuelles"
echo "  📁 exports/      - Exports HTML/PDF"
echo ""
echo "Pour démarrer le système:"
echo -e "  ${CYAN}./bibliotheque.sh${NC}"
echo ""
echo "Documentation complète:"
echo -e "  ${CYAN}cat README.md${NC}"
echo ""

# Proposer de lancer immédiatement
read -p "Voulez-vous lancer le système maintenant? (o/n): " launch_now

if [[ "$launch_now" == "o" ]] || [[ "$launch_now" == "O" ]]; then
    echo ""
    echo -e "${CYAN}Lancement du système...${NC}"
    echo ""
    sleep 1
    ./bibliotheque.sh
else
    echo ""
    echo -e "${GREEN}À bientôt! 📚${NC}"
fi