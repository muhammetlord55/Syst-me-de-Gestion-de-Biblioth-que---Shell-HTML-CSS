#!/bin/bash

################################################################################
# GÉNÉRATEUR DE DONNÉES DE TEST
# Crée un jeu de données réaliste pour tester le système
################################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${SCRIPT_DIR}/data"
LIVRES_FILE="${DATA_DIR}/livres.txt"
EMPRUNTS_FILE="${DATA_DIR}/emprunts.txt"

# Créer le dossier data si nécessaire
mkdir -p "$DATA_DIR"

echo "=== GÉNÉRATION DES DONNÉES DE TEST ==="
echo ""

# Initialiser le fichier des livres
cat > "$LIVRES_FILE" << 'EOF'
# ID|Titre|Auteur|Année|Genre|Statut
001|1984|George Orwell|1949|Dystopie|disponible
002|Le Meilleur des mondes|Aldous Huxley|1932|Dystopie|disponible
003|Fondation|Isaac Asimov|1951|Science-Fiction|emprunté
004|Dune|Frank Herbert|1965|Science-Fiction|disponible
005|Le Seigneur des Anneaux|J.R.R. Tolkien|1954|Fantasy|disponible
006|Harry Potter à l'école des sorciers|J.K. Rowling|1997|Fantasy|emprunté
007|Le Nom de la rose|Umberto Eco|1980|Roman|disponible
008|Cent ans de solitude|Gabriel García Márquez|1967|Roman|disponible
009|L'Étranger|Albert Camus|1942|Roman|disponible
010|Crime et Châtiment|Fiodor Dostoïevski|1866|Roman|disponible
011|Les Misérables|Victor Hugo|1862|Roman|disponible
012|Orgueil et Préjugés|Jane Austen|1813|Roman|disponible
013|Le Comte de Monte-Cristo|Alexandre Dumas|1844|Roman|disponible
014|Guerre et Paix|Léon Tolstoï|1869|Roman|disponible
015|Moby Dick|Herman Melville|1851|Roman|disponible
016|Le Petit Prince|Antoine de Saint-Exupéry|1943|Conte|disponible
017|Da Vinci Code|Dan Brown|2003|Thriller|emprunté
018|Gone Girl|Gillian Flynn|2012|Thriller|disponible
019|Le Silence des agneaux|Thomas Harris|1988|Thriller|disponible
020|Shining|Stephen King|1977|Horreur|disponible
021|Ça|Stephen King|1986|Horreur|disponible
022|Carrie|Stephen King|1974|Horreur|disponible
023|Les Piliers de la Terre|Ken Follett|1989|Histoire|disponible
024|Sapiens|Yuval Noah Harari|2011|Histoire|disponible
025|Homo Deus|Yuval Noah Harari|2015|Science|disponible
026|Brève histoire du temps|Stephen Hawking|1988|Science|disponible
027|Le Gène égoïste|Richard Dawkins|1976|Science|disponible
028|Steve Jobs|Walter Isaacson|2011|Biographie|disponible
029|Long Walk to Freedom|Nelson Mandela|1994|Biographie|disponible
030|L'Autobiographie de Malcolm X|Malcolm X|1965|Biographie|disponible
031|Le Trône de fer|George R.R. Martin|1996|Fantasy|disponible
032|Neuromancien|William Gibson|1984|Science-Fiction|disponible
033|Le Guide du voyageur galactique|Douglas Adams|1979|Science-Fiction|disponible
034|Les Robots|Isaac Asimov|1950|Science-Fiction|disponible
035|2001: L'Odyssée de l'espace|Arthur C. Clarke|1968|Science-Fiction|disponible
036|Fahrenheit 451|Ray Bradbury|1953|Dystopie|disponible
037|La Servante écarlate|Margaret Atwood|1985|Dystopie|disponible
038|V pour Vendetta|Alan Moore|1988|Dystopie|disponible
039|Orange mécanique|Anthony Burgess|1962|Dystopie|disponible
040|Le Rapport de Brodie|Jorge Luis Borges|1970|Nouvelles|disponible
041|Fictions|Jorge Luis Borges|1944|Nouvelles|disponible
042|Les Fleurs du mal|Charles Baudelaire|1857|Poésie|disponible
043|Gatsby le Magnifique|F. Scott Fitzgerald|1925|Roman|disponible
044|Sur la route|Jack Kerouac|1957|Roman|disponible
045|L'Attrape-cœurs|J.D. Salinger|1951|Roman|disponible
046|Lolita|Vladimir Nabokov|1955|Roman|disponible
047|Les Raisins de la colère|John Steinbeck|1939|Roman|disponible
048|Vol au-dessus d'un nid de coucou|Ken Kesey|1962|Roman|disponible
049|Le Vieil Homme et la Mer|Ernest Hemingway|1952|Roman|disponible
050|Pour qui sonne le glas|Ernest Hemingway|1940|Roman|disponible
051|Mrs Dalloway|Virginia Woolf|1925|Roman|disponible
052|La Promenade au phare|Virginia Woolf|1927|Roman|disponible
053|Ulysse|James Joyce|1922|Roman|disponible
054|À la recherche du temps perdu|Marcel Proust|1913|Roman|disponible
055|La Peste|Albert Camus|1947|Roman|disponible
056|Le Procès|Franz Kafka|1925|Roman|disponible
057|La Métamorphose|Franz Kafka|1915|Nouvelles|disponible
058|Le Château|Franz Kafka|1926|Roman|disponible
059|Les Frères Karamazov|Fiodor Dostoïevski|1880|Roman|disponible
060|L'Idiot|Fiodor Dostoïevski|1869|Roman|disponible
061|Anna Karénine|Léon Tolstoï|1877|Roman|disponible
062|Madame Bovary|Gustave Flaubert|1857|Roman|disponible
063|Le Rouge et le Noir|Stendhal|1830|Roman|disponible
064|Germinal|Émile Zola|1885|Roman|disponible
065|Nana|Émile Zola|1880|Roman|disponible
066|Le Père Goriot|Honoré de Balzac|1835|Roman|disponible
067|Eugénie Grandet|Honoré de Balzac|1833|Roman|disponible
068|Les Trois Mousquetaires|Alexandre Dumas|1844|Roman|disponible
069|Notre-Dame de Paris|Victor Hugo|1831|Roman|disponible
070|Vingt mille lieues sous les mers|Jules Verne|1870|Aventure|disponible
071|Le Tour du monde en 80 jours|Jules Verne|1872|Aventure|disponible
072|Voyage au centre de la Terre|Jules Verne|1864|Aventure|disponible
073|Robinson Crusoé|Daniel Defoe|1719|Aventure|disponible
074|L'Île au trésor|Robert Louis Stevenson|1883|Aventure|disponible
075|Les Aventures de Tom Sawyer|Mark Twain|1876|Aventure|disponible
076|Les Hauts de Hurlevent|Emily Brontë|1847|Roman|disponible
077|Jane Eyre|Charlotte Brontë|1847|Roman|disponible
078|Emma|Jane Austen|1815|Roman|disponible
079|Raison et Sentiments|Jane Austen|1811|Roman|disponible
080|Dracula|Bram Stoker|1897|Horreur|disponible
081|Frankenstein|Mary Shelley|1818|Horreur|disponible
082|Le Portrait de Dorian Gray|Oscar Wilde|1890|Roman|disponible
083|Alice au pays des merveilles|Lewis Carroll|1865|Fantasy|disponible
084|Le Magicien d'Oz|L. Frank Baum|1900|Fantasy|disponible
085|Peter Pan|J.M. Barrie|1911|Fantasy|disponible
086|Le Hobbit|J.R.R. Tolkien|1937|Fantasy|disponible
087|Chroniques de Narnia|C.S. Lewis|1950|Fantasy|disponible
088|La Roue du Temps|Robert Jordan|1990|Fantasy|disponible
089|Le Nom du vent|Patrick Rothfuss|2007|Fantasy|disponible
090|Assassin Royal|Robin Hobb|1995|Fantasy|disponible
091|Terremer|Ursula K. Le Guin|1968|Fantasy|disponible
092|La Horde du Contrevent|Alain Damasio|2004|Fantasy|disponible
093|La Zone du dehors|Alain Damasio|1999|Science-Fiction|disponible
094|Ravage|René Barjavel|1943|Science-Fiction|disponible
095|La Nuit des temps|René Barjavel|1968|Science-Fiction|disponible
096|Le Hussard sur le toit|Jean Giono|1951|Roman|disponible
097|Un roi sans divertissement|Jean Giono|1947|Roman|disponible
098|L'Écume des jours|Boris Vian|1947|Roman|disponible
099|Zazie dans le métro|Raymond Queneau|1959|Roman|disponible
100|Exercices de style|Raymond Queneau|1947|Nouvelles|disponible
EOF

echo "✓ $LIVRES_FILE créé avec 100 livres"

# Initialiser le fichier des emprunts
cat > "$EMPRUNTS_FILE" << EOF
# ID_Livre|Emprunteur|Date_Emprunt|Date_Retour_Prévue|Statut
003|Marie Dubois|2024-10-15|2024-10-29|en_cours
006|Jean Martin|2024-10-20|2024-11-03|en_cours
017|Sophie Lefebvre|2024-11-01|2024-11-15|en_cours
001|Pierre Durant|2024-09-10|2024-09-24|retourné_2024-09-22
005|Julie Bernard|2024-09-15|2024-09-29|retourné_2024-09-28
020|Marc Petit|2024-10-01|2024-10-15|retourné_2024-10-14
024|Isabelle Moreau|2024-08-20|2024-09-03|retourné_2024-09-01
EOF

echo "✓ $EMPRUNTS_FILE créé avec des exemples d'emprunts"

echo ""
echo "=== DONNÉES DE TEST GÉNÉRÉES AVEC SUCCÈS ==="
echo ""
echo "Statistiques:"
echo "  - 100 livres dans différents genres"
echo "  - 3 livres actuellement empruntés"
echo "  - 4 emprunts dans l'historique"
echo ""
echo "Lancement du système de gestion de bibliothèque..."

sleep 10

bash bibliotheque.sh