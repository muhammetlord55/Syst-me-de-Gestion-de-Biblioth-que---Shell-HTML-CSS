#!/bin/bash

################################################################################
# BIBLIOTHÈQUE DE FONCTIONS - GESTION DE BIBLIOTHÈQUE
# Contient toutes les fonctions réutilisables du système
################################################################################

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

################################################################################
# FONCTIONS UTILITAIRES
################################################################################

# Pause pour l'utilisateur
pause() {
    echo ""
    read -p "Appuyez sur Entrée pour continuer..."
}

# Afficher une bannière
afficher_banniere() {
    echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║                                                            ║${NC}"
    echo -e "${CYAN}║        📚 SYSTÈME DE GESTION DE BIBLIOTHÈQUE 📚            ║${NC}"
    echo -e "${CYAN}║                     Version 1.0                            ║${NC}"
    echo -e "${CYAN}║                                                            ║${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
}

# Dessiner le logo BU
dessiner_BU() {
    bleu=$(tput setaf 6)
    jaune=$(tput setaf 3)
    reset=$(tput sgr0)

    echo "${bleu}"
    cat << "EOF"
██████╗ ██╗██████╗ ██╗     ██╗ ██████╗ ████████╗██╗  ██╗███████╗ ██████╗ ██╗   ██╗███████╗
██╔══██╗██║██╔══██╗██║     ██║██╔═══██╗╚══██╔══╝██║  ██║██╔════╝██╔═══██╗██║   ██║██╔════╝
██████╔╝██║██████╔╝██║     ██║██║   ██║   ██║   ██████╔╝█████╗  ██║   ██║██║   ██║███████╗
██╔══██╗██║██╔══██╗██║     ██║██║   ██║   ██║   ██╔══██╗██╔══╝  ██║   ██║██║   ██║██╔════╝
██████╔╝██║██████╔╝███████╗██║╚██████╔╝   ██║   ██║  ██║███████╗╚██████╔╝╚██████╔╝████████╗
╚═════╝ ╚═╝╚═════╝ ╚══════╝╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝  ╚═════╝ ╚═══════╝
EOF
    echo "${jaune}                      📚  VOTRE SAVOIR, À PORTÉE DE TERMINAL  📚${reset}"
}


# Vérifier et créer la structure des dossiers
verifier_structure() {
    local dirs=("$DATA_DIR" "$BACKUP_DIR" "$EXPORT_DIR")

    for dir in "${dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
        fi
    done

    # Créer les fichiers s'ils n'existent pas
    if [[ ! -f "$LIVRES_FILE" ]]; then
        echo "# ID|Titre|Auteur|Année|Genre|Statut" > "$LIVRES_FILE"
    fi

    if [[ ! -f "$EMPRUNTS_FILE" ]]; then
        echo "# ID_Livre|Emprunteur|Date_Emprunt|Date_Retour_Prévue|Statut" > "$EMPRUNTS_FILE"
    fi
}

# Valider une date (format YYYY-MM-DD)
valider_date() {
    local date=$1
    if [[ $date =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
       return 0
    else
        return 1
    fi
}

# Valider une année (format YYYY)
valider_annee() {
    local annee=$1
    if [[ $annee =~ ^[0-9]{4}$ ]] && [[ $annee -ge 1000 ]] && [[ $annee -le $(date +%Y) ]]; then
        return 0
    else
        return 1
    fi
}

# Générer un nouvel ID unique
generer_id() {
    local max_id=0
    
    if [[ -f "$LIVRES_FILE" ]]; then
        while IFS='|' read -r id reste; do
            # Ignorer les lignes de commentaire
            [[ $id =~ ^# ]] && continue
            [[ -z $id ]] && continue
            
            # Extraire le numéro de l'ID (ex: 001 -> 1)
            local num_id=$((10#$id))
            if [[ $num_id -gt $max_id ]]; then
                max_id=$num_id
            fi
        done < "$LIVRES_FILE"
    fi
    
    # Incrémenter et formater sur 3 chiffres
    local nouvel_id=$((max_id + 1))
    printf "%03d" $nouvel_id
}

afficher_genres() {
    echo ""
    echo "  Genres disponibles:"
    echo ""
    echo "1. Roman       2. Science-Fiction    3. Fantasy"
    echo "4. Thriller    5. Policier           6. Biographie"
    echo "7. Histoire    8. Science            9. Autre"
    echo ""
    echo "Choisissez un genre (ou tapez le vôtre) "
    echo ""
}

################################################################################
# GESTION DES LIVRES
################################################################################
# Ajouter un livre
ajouter_livre() {
    clear
    echo -e "${GREEN}=== AJOUTER UN NOUVEAU LIVRE ===${NC}"
    echo ""
    
    # Génération automatique de l'ID
    local id=$(generer_id)
    echo -e "ID généré automatiquement: ${CYAN}$id${NC}"
    echo ""
    
    # Saisie du titre
    while true; do
        read -p "Titre du livre: " titre
        if [[ -n "$titre" ]]; then
            break
        else
            echo -e "${RED}Le titre ne peut pas être vide!${NC}"
        fi
    done
    
    # Saisie de l'auteur
    while true; do
        read -p "Auteur: " auteur
        if [[ -n "$auteur" ]]; then
            break
        else
            echo -e "${RED}L'auteur ne peut pas être vide!${NC}"
        fi
    done
    
    # Saisie de l'année
    while true; do
        read -p "Année de publication (YYYY): " annee
        if valider_annee "$annee"; then
            break
        else
            echo -e "${RED}Année invalide! Format attendu: YYYY (ex: 2024)${NC}"
        fi
    done
    
    # Saisie du genre
    echo ""
    echo "Genres disponibles:"
    echo "1. Roman       2. Science-Fiction    3. Fantasy"
    echo "4. Thriller    5. Policier           6. Biographie"
    echo "7. Histoire    8. Science            9. Autre"
    read -p "Choisissez un genre (ou tapez le vôtre): " genre_choix
    
    case $genre_choix in
        1) genre="Roman" ;;
        2) genre="Science-Fiction" ;;
        3) genre="Fantasy" ;;
        4) genre="Thriller" ;;
        5) genre="Policier" ;;
        6) genre="Biographie" ;;
        7) genre="Histoire" ;;
        8) genre="Science" ;;
        9) read -p "Entrez le genre: " genre ;;
        *) genre="$genre_choix" ;;
    esac
    
    # Statut par défaut
    local statut="disponible"
    
    # Enregistrement dans le fichier
    echo "$id|$titre|$auteur|$annee|$genre|$statut" >> "$LIVRES_FILE"
    
    echo ""
    echo -e "${GREEN}✓ Livre ajouté avec succès!${NC}"
    echo ""
    echo "Récapitulatif:"
    echo "  ID:      $id"
    echo "  Titre:   $titre"
    echo "  Auteur:  $auteur"
    echo "  Année:   $annee"
    echo "  Genre:   $genre"
    echo "  Statut:  $statut"
    
    pause
}

# Modifier un livre
modifier_livre() {
    clear
    echo -e "${YELLOW}=== MODIFIER UN LIVRE ===${NC}"
    echo ""

    read -rp "Entrez l'ID du livre à modifier: " id

    ligne=$(grep -E "^${id}\|" "$LIVRES_FILE" || true)
    if [[ -z "$ligne" ]]; then
        echo -e "${RED}✗ Livre non trouvé !${NC}"
        pause
        return 1
    fi

    IFS='|' read -r lid titre auteur annee genre statut <<< "$ligne"

    echo ""
    echo "Informations actuelles :"
    echo "  Titre:   $titre"
    echo "  Auteur:  $auteur"
    echo "  Année:   $annee"
    echo "  Genre:   $genre"
    echo "  Statut:  $statut"
    echo ""

    read -rp "Nouveau titre (Entrée pour conserver): " new_titre
    [[ -z "$new_titre" ]] && new_titre="$titre"

    read -rp "Nouvel auteur (Entrée pour conserver): " new_auteur
    [[ -z "$new_auteur" ]] && new_auteur="$auteur"

    while true; do
        read -rp "Nouvelle année (Entrée pour conserver): " new_annee
        if [[ -z "$new_annee" ]]; then
            new_annee="$annee"
            break
        elif valider_annee "$new_annee"; then
            break
        else
            echo -e "${RED}Année invalide !${NC}"
        fi
    done

    read -rp "Nouveau genre (Entrée pour conserver): " new_genre
    [[ -z "$new_genre" ]] && new_genre="$genre"

    read -rp "Nouveau statut (disponible/emprunté) (Entrée pour conserver): " new_statut
    [[ -z "$new_statut" ]] && new_statut="$statut"

    # Construire la nouvelle ligne (ne pas oublier d'échapper les pipes si tu veux les autoriser)
    nouvelle_ligne="${lid}|${new_titre}|${new_auteur}|${new_annee}|${new_genre}|${new_statut}"

    echo ""
    read -rp "Créer un fichier backup avant modification ? (o/n): " rep
    if [[ "$rep" =~ ^[oOyY]$ ]]; then
        backup="${LIVRES_FILE}.bak_$(date +%Y%m%d_%H%M%S)"
        cp -- "$LIVRES_FILE" "$backup"
        echo -e "${BLUE}✓ Backup créé : $backup${NC}"
    fi

    # Fonction d'échappement pour sed (remplacement)
    escape_for_sed() {
      printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/&/\\&/g' -e 's/@/\\@/g' -e 's/\//\\\//g'
    }

    escaped_replacement=$(escape_for_sed "$nouvelle_ligne")

    # Utiliser @ comme délimiteur pour éviter conflits avec / et |
    if sed --version >/dev/null 2>&1; then
        # GNU sed
        sed -i "s@^${id}|.*@${escaped_replacement}@" "$LIVRES_FILE"
    else
        # BSD/macOS sed : inplace with backup suffix
        sed -i .bak "s@^${id}|.*@${escaped_replacement}@" "$LIVRES_FILE" && rm -f "${LIVRES_FILE}.bak"
    fi

    echo ""
    echo -e "${GREEN}✓ Livre modifié avec succès !${NC}"
    pause
}

# Supprimer un livre
supprimer_livre() {
    clear
    echo -e "${RED}=== SUPPRIMER UN LIVRE ===${NC}"
    echo ""

    read -rp "Entrez l'ID du livre à supprimer: " id

    # Vérifier l'existence de l'entrée via grep
    ligne=$(grep -E "^${id}\|" "$LIVRES_FILE" || true)

    if [[ -z "$ligne" ]]; then
        echo -e "${RED}✗ Livre non trouvé !${NC}"
        pause
        return 1
    fi

    # Afficher informations
    IFS='|' read -r lid titre auteur annee genre statut <<< "$ligne"
    echo ""
    echo "Livre trouvé :"
    echo "  Titre :  $titre"
    echo "  Auteur : $auteur"
    echo ""

    read -rp "Voulez-vous vraiment supprimer ce livre ? (o/n): " confirm
    if [[ ! "$confirm" =~ ^[oOyY]$ ]]; then
        echo -e "${YELLOW}Annulation. Aucun livre supprimé.${NC}"
        pause
        return 0
    fi

    # Demande backup
    read -rp "Créer un fichier backup avant suppression ? (o/n): " rep
    if [[ "$rep" =~ ^[oOyY]$ ]]; then
        backup="${LIVRES_FILE}.bak_$(date +%Y%m%d_%H%M%S)"
        cp -- "$LIVRES_FILE" "$backup"
        echo -e "${BLUE}✓ Backup créé : $backup${NC}"
    fi

    # Suppression via sed (ligne commençant par id|)
    if sed --version >/dev/null 2>&1; then
        # GNU sed
        sed -i "/^${id}|/d" "$LIVRES_FILE"
    else
        # BSD/macOS sed
        sed -i .bak "/^${id}|/d" "$LIVRES_FILE" && rm -f "${LIVRES_FILE}.bak"
    fi

    echo ""
    echo -e "${GREEN}✓ Livre supprimé avec succès !${NC}"
    pause
}

# Lister tous les livres avec pagination
lister_livres() {
    clear
    echo -e "${CYAN}=== LISTE DE TOUS LES LIVRES ===${NC}"
    echo ""

    local par_page=10
    local page=1
    local count=0

    # Compter les livres valides
    local total=$(grep -vE "^#|^$" "$LIVRES_FILE" | wc -l)

    if [[ $total -eq 0 ]]; then
        echo "Aucun livre dans la bibliothèque."
        pause
        return
    fi

    # Calcul du nombre de pages
    local total_pages=$(( (total + par_page - 1) / par_page ))

    echo "Total : $total livre(s)"
    echo ""
    printf "%-5s \t %-35s \t %-25s \t %-6s \t\t %-20s \t %-12s\n" "ID" "Titre" "Auteur" "Année" "Genre" "Statut"
    echo "─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"

    # Lecture ligne par ligne
    while IFS='|' read -r id titre auteur annee genre statut; do
        
        [[ -z "$id" || "$id" =~ ^# ]] && continue

        ((count++))

        # Tronquer les textes
        titre_court="${titre:0:28}"
        auteur_court="${auteur:0:23}"
        genre_court="${genre:0:18}"

        printf "%-5s \t %-35s \t %-25s \t %-6s \t %-20s \t %-12s\n" \
            "$id" "$titre_court" "$auteur_court" "$annee" "$genre_court" "$statut"

        # Gestion pagination
        if (( count % par_page == 0 )) && (( count < total )); then
            echo ""
            read -r -p "Page $page/$total_pages - Appuyez sur Entrée pour continuer (q = quitter) : " next </dev/tty
            [[ "$next" == "q" ]] && return
            ((page++))

            clear
            echo -e "${CYAN}=== LISTE DE TOUS LES LIVRES ===${NC}"
            echo ""
            printf "%-5s \t %-35s \t %-25s \t %-6s \t\t %-20s \t %-12s\n" "ID" "Titre" "Auteur" "Année" "Genre" "Statut"
            echo "─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
        fi

    done < <(grep -vE "^#|^$" "$LIVRES_FILE")

    echo ""
    pause
}

# Afficher un livre par ID
afficher_livre_par_id() {
    clear
    echo -e "${CYAN}=== AFFICHER UN LIVRE ===${NC}"
    echo ""
    
    read -p "Entrez l'ID du livre: " id
    
    local trouve=false
    
    while IFS='|' read -r lid titre auteur annee genre statut; do
        [[ $lid =~ ^# ]] && continue
        
        if [[ "$lid" == "$id" ]]; then
            trouve=true
            echo ""
            echo "╔════════════════════════════════════════════════════════════╗"
            echo "  ID:      $lid"
            echo "  Titre:   $titre"
            echo "  Auteur:  $auteur"
            echo "  Année:   $annee"
            echo "  Genre:   $genre"
            echo "  Statut:  $statut"
            echo "╚════════════════════════════════════════════════════════════╝"
            break
        fi
    done < "$LIVRES_FILE"
    
    if [[ "$trouve" == false ]]; then
        echo -e "${RED}✗ Livre non trouvé!${NC}"
    fi
    
    pause
}

################################################################################
# RECHERCHE ET FILTRES
################################################################################

# Rechercher par titre (recherche partielle)
rechercher_par_titre() {
    clear
    echo -e "${CYAN}=== RECHERCHE PAR TITRE ===${NC}"
    echo ""
    
    read -p "Entrez le titre (ou partie du titre): " recherche
    
    local count=0
    
    echo ""
    printf "%-5s %-30s \t %-25s \t %-6s \t\t %-20s\n" "ID" "Titre" "Auteur" "Année" "Genre"
    echo "──────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        # Recherche insensible à la casse
        if [[ "${titre,,}" == *"${recherche,,}"* ]]; then
            ((count++))
            printf "%-5s %-30s \t %-25s \t %-6s \t %-20s\n" \
                "$id" "${titre:0:28}" "${auteur:0:23}" "$annee" "${genre:0:18}"
        fi
    done < "$LIVRES_FILE"
    
    echo ""
    echo "Résultat(s) trouvé(s): $count"
    pause
}

# Rechercher par auteur
rechercher_par_auteur() {
    clear
    echo -e "${CYAN}=== RECHERCHE PAR AUTEUR ===${NC}"
    echo ""
    
    read -p "Entrez le nom de l'auteur: " recherche
    
    local count=0
    
    echo ""
    printf "%-5s %-30s \t %-25s \t %-6s \t\t %-20s\n" "ID" "Titre" "Auteur" "Année" "Genre"
    echo "────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        if [[ "${auteur,,}" == *"${recherche,,}"* ]]; then
            ((count++))
            printf "%-5s %-30s \t %-25s \t %-6s \t %-20s\n" \
                "$id" "${titre:0:28}" "${auteur:0:23}" "$annee" "${genre:0:18}"
        fi
    done < "$LIVRES_FILE"
    
    echo ""
    echo "Résultat(s) trouvé(s): $count"
    pause
}

# Filtrer par genre
filtrer_par_genre() {
    clear
    echo -e "${CYAN}=== FILTRER PAR GENRE ===${NC}"
    echo ""
    
    afficher_genres
    read -p "Entrez le genre: " genre_recherche
    
    local count=0
    
    echo ""
    printf "%-5s %-30s \t %-25s \t %-6s\n" "ID" "Titre" "Auteur" "Année"
    echo "────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        if [[ "${genre,,}" == *"${genre_recherche,,}"* ]]; then
            ((count++))
            printf "%-5s %-30s \t %-25s \t %-6s\n" \
                "$id" "${titre:0:28}" "${auteur:0:23}" "$annee"
        fi
    done < "$LIVRES_FILE"
    
    echo ""
    echo "Résultat(s) trouvé(s): $count"
    pause
}

# Filtrer par année (plage)
filtrer_par_annee() {
    clear
    echo -e "${CYAN}=== FILTRER PAR ANNÉE ===${NC}"
    echo ""
    
    while true; do
        read -p "Année de début (YYYY): " annee_debut
        if valider_annee "$annee_debut"; then
            break
        else
            echo -e "${RED}Année invalide!${NC}"
        fi
    done
    
    while true; do
        read -p "Année de fin (YYYY): " annee_fin
        if valider_annee "$annee_fin"; then
            if [[ $annee_fin -ge $annee_debut ]]; then
                break
            else
                echo -e "${RED}L'année de fin doit être >= année de début!${NC}"
            fi
        else
            echo -e "${RED}Année invalide!${NC}"
        fi
    done
    
    local count=0
    
    echo ""
    printf "%-5s %-30s %-25s %-6s \t %-20s\n" "ID" "Titre" "Auteur" "Année" "Genre"
    echo "────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        if [[ $annee -ge $annee_debut ]] && [[ $annee -le $annee_fin ]]; then
            ((count++))
            printf "%-5s %-30s %-25s %-6s \t %-20s\n" \
                "$id" "${titre:0:28}" "${auteur:0:23}" "$annee" "${genre:0:18}"
        fi
    done < "$LIVRES_FILE"
    
    echo ""
    echo "Résultat(s) trouvé(s): $count"
    pause
}

# Recherche avancée (multi-critères)
recherche_avancee() {
    clear
    echo -e "${CYAN}=== RECHERCHE AVANCÉE ===${NC}"
    echo ""
    echo "Laissez vide pour ignorer un critère"
    echo ""
    
    read -p "Titre (partiel): " titre_rech
    read -p "Auteur (partiel): " auteur_rech
    read -p "Genre (partiel): " genre_rech
    read -p "Année min: " annee_min
    read -p "Année max: " annee_max
    read -p "Statut (disponible/emprunté): " statut_rech
    
    local count=0
    
    echo ""
    printf "%-5s \t %-25s \t %-20s \t %-6s \t\t\t %-15s \t %-12s\n" "ID" "Titre" "Auteur" "Année" "Genre" "Statut"
    echo "──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        local match=true
        
        # Vérifier chaque critère
        [[ -n "$titre_rech" ]] && [[ ! "${titre,,}" == *"${titre_rech,,}"* ]] && match=false
        [[ -n "$auteur_rech" ]] && [[ ! "${auteur,,}" == *"${auteur_rech,,}"* ]] && match=false
        [[ -n "$genre_rech" ]] && [[ ! "${genre,,}" == *"${genre_rech,,}"* ]] && match=false
        [[ -n "$annee_min" ]] && [[ $annee -lt $annee_min ]] && match=false
        [[ -n "$annee_max" ]] && [[ $annee -gt $annee_max ]] && match=false
        [[ -n "$statut_rech" ]] && [[ ! "${statut,,}" == *"${statut_rech,,}"* ]] && match=false
        
        if [[ "$match" == true ]]; then
            ((count++))
            printf "%-5s \t %-25s \t %-20s \t %-6s \t\t %-15s \t %-12s\n" \
                "$id" "${titre:0:23}" "${auteur:0:18}" "$annee" "${genre:0:13}" "$statut"
        fi
    done < "$LIVRES_FILE"
    
    echo ""
    echo "Résultat(s) trouvé(s): $count"
    pause
}


################################################################################
# GESTION DES EMPRUNTS
################################################################################

# Emprunter un livre
emprunter_livre() {
    clear
    echo -e "${GREEN}=== EMPRUNTER UN LIVRE ===${NC}"
    echo ""
    
    read -p "ID du livre: " id_livre
    
    # Vérifier si le livre existe et est disponible
    local livre_disponible=false
    local titre_livre=""
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        if [[ "$id" == "$id_livre" ]]; then
            titre_livre="$titre"
            if [[ "$statut" == "disponible" ]]; then
                livre_disponible=true
            else
                echo -e "${RED}✗ Ce livre est déjà emprunté!${NC}"
                pause
                return
            fi
            break
        fi
    done < "$LIVRES_FILE"
    
    if [[ "$livre_disponible" == false ]]; then
        echo -e "${RED}✗ Livre non trouvé ou non disponible!${NC}"
        pause
        return
    fi
    
    # Saisie de l'emprunteur
    read -p "Nom de l'emprunteur: " emprunteur
    
    # Date d’emprunt
    local date_emprunt=$(date +%Y-%m-%d)

    # Date prévue de retour
    local date_retour=$(date -d "+14 days" +%Y-%m-%d 2>/dev/null || date -v +14d +%Y-%m-%d)
    
    read -p "Date de retour prévue [$date_retour]: " date_retour_input
    [[ -n "$date_retour_input" ]] && date_retour="$date_retour_input"
    
    # Enregistrer l’emprunt
    echo "$id_livre|$emprunteur|$date_emprunt|$date_retour|en_cours" >> "$EMPRUNTS_FILE"

    # Mise à jour du statut (ne touche pas aux autres champs)
    sed -i "s/^\(${id_livre}|[^|]*|[^|]*|[^|]*|[^|]*|\)disponible$/\1emprunté/" "$LIVRES_FILE"

    echo ""
    echo -e "${GREEN}✓ Emprunt enregistré avec succès!${NC}"
    echo ""
    echo "Livre:           $titre_livre"
    echo "Emprunteur:      $emprunteur"
    echo "Date d'emprunt:  $date_emprunt"
    echo "Retour prévu:    $date_retour"

    pause
}

# Retourner un livre
retourner_livre() {
    clear
    echo -e "${YELLOW}=== RETOURNER UN LIVRE ===${NC}"
    echo ""
    
    read -p "ID du livre: " id_livre

    # Vérifier si un emprunt en cours existe
    local emprunt_existe=false
    local ligne_emprunt=$(grep "^${id_livre}|.*|.*|.*|en_cours$" "$EMPRUNTS_FILE")

    if [[ -n "$ligne_emprunt" ]]; then
        emprunt_existe=true

        # Extraire les champs
        IFS='|' read -r id emprunteur date_emp date_ret statut_emp <<< "$ligne_emprunt"

        echo ""
        echo "Emprunteur: $emprunteur"
        echo "Date d'emprunt: $date_emp"
        echo "Retour prévu: $date_ret"
        echo ""

        # Date de retour réelle
        local date_retour_reelle=$(date +%Y-%m-%d)

        # 🔥 Modifier l'emprunt dans EMPRUNTS_FILE avec sed
        sed -i "s/^${id_livre}|${emprunteur}|${date_emp}|${date_ret}|en_cours$/${id_livre}|${emprunteur}|${date_emp}|${date_ret}|retourné_${date_retour_reelle}/" "$EMPRUNTS_FILE"

        # 🔥 Modifier le livre dans LIVRES_FILE avec sed
        sed -i "s/^${id_livre}|\([^|]*|\)\{4\}[^|]*$/${id_livre}|\1disponible/" "$LIVRES_FILE"

        echo -e "${GREEN}✓ Livre retourné avec succès!${NC}"

    else
        echo -e "${RED}✗ Aucun emprunt en cours pour ce livre!${NC}"
    fi

    pause
}

# Lister les emprunts en cours
lister_emprunts() {
    clear
    echo -e "${CYAN}=== LISTE DES LIVRES EMPRUNTÉS ===${NC}"
    echo ""
    
    local date_actuelle=$(date +%Y-%m-%d)
    local total_retard=0
    local total_ok=0
    
    printf "%-5s \t %-25s \t %-20s \t %-15s \t %-12s \t\t
     %-8s\n" \
        "ID" "Titre" "Emprunteur" "Retour Prévu" "Statut" "Jours"
    echo "──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id emprunteur date_emp date_ret statut_emp; do
        [[ $id =~ ^# ]] && continue
        [[ "$statut_emp" != "en_cours" ]] && continue
        
        # Calcul dates (compatibilité Linux + BSD)
        local ts_now=$(date -d "$date_actuelle" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$date_actuelle" +%s)
        local ts_ret=$(date -d "$date_ret" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$date_ret" +%s)
        
        local diff=$(( (ts_now - ts_ret) / 86400 ))
        
        # Récupérer titre du livre
        local titre=""
        while IFS='|' read -r lid ltitre _; do
            [[ $lid =~ ^# ]] && continue
            if [[ "$lid" == "$id" ]]; then
                titre="$ltitre"
                break
            fi
        done < "$LIVRES_FILE"
        
        # En retard ?
        if (( diff > 0 )); then
            statut="EN RETARD"
            jours="${diff}j"
            ((total_retard++))
        else
            statut="Dans les délais"
            jours="$((-diff))j restant"
            ((total_ok++))
        fi
        
        printf "%-5s \t %-25s \t %-20s \t %-15s \t %-12s \t\t %-8s\n" \
            "$id" "${titre:0:23}" "${emprunteur:0:18}" "$date_ret" "$statut" "$jours"
    
    done < "$EMPRUNTS_FILE"
    
    echo ""
    echo "───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    echo -e "📘 Total emprunts dans les délais : ${GREEN}$total_ok${NC}"
    echo -e "⛔ Total emprunts en retard       : ${RED}$total_retard${NC}"
    echo ""
    
    pause
}


# Historique des emprunts
historique_emprunts() {
    clear
    echo -e "${CYAN}=== HISTORIQUE DES EMPRUNTS ===${NC}"
    echo ""
    
    read -p "Filtrer par ID livre (laisser vide pour tout): " id_filtre
    
    local count=0
    
    printf "%-5s \t %-20s \t %-20s \t %-12s \t %-12s \t %-15s\n" "ID" "Titre" "Emprunteur" "Date Emp." "Retour Prévu" "Statut"
    echo "──────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id emprunteur date_emp date_ret statut_emp; do
        [[ $id =~ ^# ]] && continue
        
        # Appliquer le filtre si nécessaire
        if [[ -n "$id_filtre" ]] && [[ "$id" != "$id_filtre" ]]; then
            continue
        fi
        
        ((count++))
        
        # Récupérer le titre du livre
        local titre=""
        while IFS='|' read -r lid ltitre reste; do
            [[ $lid =~ ^# ]] && continue
            if [[ "$lid" == "$id" ]]; then
                titre="$ltitre"
                break
            fi
        done < "$LIVRES_FILE"
        
        printf "%-5s \t %-20s \t %-20s \t %-12s \t %-12s \t %-15s\n" \
            "$id" "${titre:0:18}" "${emprunteur:0:18}" "$date_emp" "$date_ret" "${statut_emp:0:13}"
    done < "$EMPRUNTS_FILE"
    
    echo ""
    echo "Total: $count enregistrement(s)"
    pause
}

# Vérifier les retards
verifier_retards() {
    clear
    echo -e "${RED}=== ALERTES RETARDS ===${NC}"
    echo ""
    
    local date_actuelle=$(date +%Y-%m-%d)
    local count=0
    
    printf "%-5s \t %-25s \t %-20s \t %-12s \t %-6s\n" "ID" "Titre" "Emprunteur" "Retour Prévu" "Retard"
    echo "──────────────────────────────────────────────────────────────────────────────────────────────────────────────────"
    
    while IFS='|' read -r id emprunteur date_emp date_ret statut_emp; do
        [[ $id =~ ^# ]] && continue
        
        if [[ "$statut_emp" == "en_cours" ]]; then
            # Comparer les dates
            if [[ "$date_ret" < "$date_actuelle" ]]; then
                ((count++))
                
                # Calculer le nombre de jours de retard
                # Compatible Linux et macOS
                local retard_sec=$(($(date -d "$date_actuelle" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$date_actuelle" +%s) - $(date -d "$date_ret" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$date_ret" +%s)))
                local retard_jours=$((retard_sec / 86400))
                
                # Récupérer le titre du livre
                local titre=""
                while IFS='|' read -r lid ltitre reste; do
                    [[ $lid =~ ^# ]] && continue
                    if [[ "$lid" == "$id" ]]; then
                        titre="$ltitre"
                        break
                    fi
                done < "$LIVRES_FILE"
                
                # Afficher la ligne avec retard en rouge
                printf "%-5s \t %-25s \t %-20s \t %-12s \t %-6s\n" \
                    "$id" "${titre:0:23}" "${emprunteur:0:18}" "$date_ret" "${retard_jours}j"
            fi
        fi
    done < "$EMPRUNTS_FILE"
    
    echo ""
    if [[ $count -eq 0 ]]; then
        echo -e "${GREEN}✓ Aucun retard!${NC}"
    else
        echo -e "${RED}⚠ $count livre(s) en retard!${NC}"
    fi
    pause
}


################################################################################
# STATISTIQUES ET RAPPORTS
################################################################################

# Statistiques globales
statistiques_globales() {
    clear
    echo -e "${MAGENTA}=== STATISTIQUES GLOBALES ===${NC}"
    echo ""
    
    # Nombre total de livres
    local total_livres=$(grep -v "^#" "$LIVRES_FILE" | grep -v "^$" | wc -l)
    
    # Livres disponibles
    local dispo=$(grep -v "^#" "$LIVRES_FILE" | grep "disponible" | wc -l)
    
    # Livres empruntés
    local empruntes=$(grep -v "^#" "$LIVRES_FILE" | grep "emprunté" | wc -l)
    
    # Nombre d'auteurs uniques
    local auteurs=$(grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f3 | sort -u | wc -l)
    
    # Nombre de genres uniques
    local genres=$(grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f5 | sort -u | wc -l)
    
    # Emprunts totaux
    local total_emprunts=$(grep -v "^#" "$EMPRUNTS_FILE" | grep -v "^$" | wc -l)
    
    # Emprunts en cours
    local emprunts_cours=$(grep -v "^#" "$EMPRUNTS_FILE" | grep "en_cours" | wc -l)
    
    # Année la plus ancienne et la plus récente
    local annee_min=$(grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f4 | sort -n | head -1)
    local annee_max=$(grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f4 | sort -n | tail -1)
    
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                    BIBLIOTHÈQUE                            ║"
    echo "╠════════════════════════════════════════════════════════════╣"
    echo "  Nombre total de livres:        $total_livres"
    echo "  Livres disponibles:            $dispo"
    echo "  Livres empruntés:              $empruntes"
    echo "  Auteurs différents:            $auteurs"
    echo "  Genres différents:             $genres"
    echo "  Période couverte:              $annee_min - $annee_max"
    echo ""
    echo "╠════════════════════════════════════════════════════════════╣"
    echo "║                      EMPRUNTS                              ║"
    echo "╠════════════════════════════════════════════════════════════╣"
    echo "  Total des emprunts:            $total_emprunts"
    echo "  Emprunts en cours:             $emprunts_cours"
    echo "  Emprunts terminés:             $((total_emprunts - emprunts_cours))"
    echo "╚════════════════════════════════════════════════════════════╝"
    
    pause
}

# Répartition par genre avec graphique ASCII
repartition_genres() {
    clear
    echo -e "${MAGENTA}=== RÉPARTITION PAR GENRE ===${NC}"
    echo ""
    
    # Créer un fichier temporaire pour les genres
    local temp_genres="${DATA_DIR}/temp_genres.txt"
    grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f5 | sort | uniq -c | sort -rn > "$temp_genres"
    
    # Trouver le maximum pour l'échelle
    local max=$(head -1 "$temp_genres" | awk '{print $1}')
    
    echo "Genre                    Nombre            Graphique"
    echo "────────────────────────────────────────────────────────────────────────────────────────"
    
    while read -r count genre; do
        # Calculer la longueur de la barre (max 40 caractères)
        local barre_longueur=$((count * 40 / max))
        local barre=$(printf '█%.0s' $(seq 1 $barre_longueur))
        
        printf "%-25s %-8s \t %s\n" "${genre:0:23}" "$count" "$barre"
    done < "$temp_genres"
    
    rm -f "$temp_genres"
    
    echo ""
    pause
}

# Top 5 auteurs les plus présents
top_auteurs() {
    clear
    echo -e "${MAGENTA}=== TOP 5 AUTEURS ===${NC}"
    echo ""
    
    local temp_auteurs="${DATA_DIR}/temp_auteurs.txt"
    grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f3 | sort | uniq -c | sort -rn | head -5 > "$temp_auteurs"
    
    echo "Classement   Auteur                        Nombre de livres"
    echo "────────────────────────────────────────────────────────────"
    
    local rang=1
    while read -r count auteur; do
        printf "%-12s %-30s %s\n" "#$rang" "${auteur:0:28}" "$count"
        ((rang++))
    done < "$temp_auteurs"
    
    rm -f "$temp_auteurs"
    
    echo ""
    pause
}

# Livres par décennie
livres_par_decennie() {
    clear
    echo -e "${MAGENTA}=== LIVRES PAR DÉCENNIE ===${NC}"
    echo ""
    
    declare -A decades
    
    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        
        # Calculer la décennie
        local decennie=$((annee / 10 * 10))
        ((decades[$decennie]++))
    done < "$LIVRES_FILE"
    
    echo "Décennie     Nombre de livres   Graphique"
    echo "────────────────────────────────────────────────────────────"
    
    # Trouver le maximum
    local max=0
    for count in "${decades[@]}"; do
        [[ $count -gt $max ]] && max=$count
    done
    
    # Afficher triés par décennie
    for decennie in $(printf '%s\n' "${!decades[@]}" | sort -n); do
        local count=${decades[$decennie]}
        local barre_longueur=$((count * 30 / max))
        local barre=$(printf '█%.0s' $(seq 1 $barre_longueur))
        
        printf "%-12s %-18s %s\n" "${decennie}s" "$count" "$barre"
    done
    
    echo ""
    pause
}

# Export HTML
export_html() {
    clear
    echo -e "${CYAN}=== EXPORT HTML ===${NC}"
    echo ""
    
    local date_export=$(date +%Y%m%d_%H%M%S)
    local fichier_export="${EXPORT_DIR}/bibliotheque_${date_export}.html"
    
    cat > "$fichier_export" << 'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque Personnelle - Rapport</title>
    <style>
    :root {
        --c1:#667eea;
        --c2:#764ba2;
        --light-bg:#ffffff;
        --text:#333;
    }

    /* ANIMATIONS */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(25px); }
        to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes slideDown {
        from { opacity: 0; transform: translateY(-20px); }
        to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes glowIn {
        from { box-shadow: 0 0 0 rgba(0,0,0,0); }
        to   { box-shadow: 0 10px 30px rgba(0,0,0,0.25); }
    }
    @keyframes shine {
        0% { left: -100%; }
        60% { left: 150%; }
        100% { left: 150%; }
    }

    body {
        font-family: "Segoe UI", Tahoma, Verdana, sans-serif;
        margin: 0; padding: 20px;
        background: linear-gradient(135deg, var(--c1), var(--c2));
        animation: fadeIn 0.8s ease-out;
    }

    .container {
        background: var(--light-bg);
        max-width: 1200px;
        margin: auto;
        padding: 30px;
        border-radius: 18px;
        animation: fadeIn 1s ease-out, glowIn 1.6s ease-out;
    }

    h1 {
        text-align: center;
        color: var(--c1);
        border-bottom: 3px solid var(--c1);
        padding-bottom: 15px;
        animation: slideDown 0.8s ease-out;
    }

    h2 {
        color: var(--c2);
        margin-top: 40px;
        border-left: 5px solid var(--c2);
        padding-left: 15px;
        animation: fadeIn 1s ease-out;
    }

    /* STAT CARDS */
    .stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px,1fr));
        gap: 20px;
        margin-top: 20px;
        animation: fadeIn 1s ease-out;
    }

    .stat-card {
        padding: 25px;
        color: white;
        border-radius: 15px;
        background: linear-gradient(135deg, var(--c1), var(--c2));
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        animation: fadeIn 1.2s ease-out;
    }

    .stat-card:hover {
        transform: translateY(-8px) scale(1.03);
        box-shadow: 0 14px 25px rgba(0,0,0,0.25);
    }

    .stat-card h3 {
        margin: 0;
        font-size: 2.4em;
    }
    .stat-card p {
        opacity: 0.9;
        margin-top: 8px;
    }

    /* TABLE */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
        animation: fadeIn 1.3s ease-out;
    }

    thead th {
        background: linear-gradient(135deg, var(--c1), var(--c2));
        color: white;
        padding: 12px;
        text-align: left;
        position: relative;
        overflow: hidden;
    }

    thead th::after {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 60%;
        height: 100%;
        background: rgba(255,255,255,0.2);
        transform: skewX(-25deg);
        animation: shine 4s infinite ease-in-out;
    }

    tbody tr {
        transition: background 0.25s ease, transform 0.25s ease;
        animation: fadeIn 1.4s ease-out;
    }
    tbody tr:hover {
        background: #f5f5f5;
        transform: scale(1.01);
    }

    td {
        padding: 12px;
        border-bottom: 1px solid #e0e0e0;
    }

    .disponible {
        color: #2ecc71;
        font-weight: bold;
        animation: fadeIn 1.5s ease-out;
    }
    .emprunte {
        color: #e74c3c;
        font-weight: bold;
        animation: fadeIn 1.5s ease-out;
    }

    /* FOOTER */
    .footer {
        text-align: center;
        margin-top: 40px;
        color: #777;
        animation: fadeIn 1.7s ease-out;
    }

    .para {
       text-align: center;
       color: #888;
    }

</style>
</head>
<body>
    <div class="container">
        <h1>📚 Bibliothèque Personnelle</h1>

EOF

    # Statistiques globales
    local total_livres=$(grep -v "^#" "$LIVRES_FILE" | grep -v "^$" | wc -l)
    local dispo=$(grep -v "^#" "$LIVRES_FILE" | grep "disponible" | wc -l)
    local empruntes=$(grep -v "^#" "$LIVRES_FILE" | grep "emprunté" | wc -l)
    local auteurs=$(grep -v "^#" "$LIVRES_FILE" | cut -d'|' -f3 | sort -u | wc -l)
    
    cat >> "$fichier_export" << EOF
        <p class="para">Rapport généré le $(date '+%d/%m/%Y à %H:%M')</p>
        <h2>Statistiques</h2>
        <div class="stats">
            <div class="stat-card">
                <h3>$total_livres</h3>
                <p>Livres au total</p>
            </div>
            <div class="stat-card">
                <h3>$dispo</h3>
                <p>Disponibles</p>
            </div>
            <div class="stat-card">
                <h3>$empruntes</h3>
                <p>Empruntés</p>
            </div>
            <div class="stat-card">
                <h3>$auteurs</h3>
                <p>Auteurs</p>
            </div>
        </div>

        <h2>Liste des Livres</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Année</th>
                    <th>Genre</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
EOF

    while IFS='|' read -r id titre auteur annee genre statut; do
        [[ $id =~ ^# ]] && continue
        [[ -z $id ]] && continue
        
        local classe_statut="disponible"
        [[ "$statut" == "emprunté" ]] && classe_statut="emprunte"
        
        cat >> "$fichier_export" << EOF
                <tr>
                    <td>$id</td>
                    <td>$titre</td>
                    <td>$auteur</td>
                    <td>$annee</td>
                    <td>$genre</td>
                    <td class="$classe_statut">$statut</td>
                </tr>
EOF
    done < "$LIVRES_FILE"
    
    cat >> "$fichier_export" << 'EOF'
            </tbody>
        </table>

        <div class="footer">
            <p>Système de Gestion de Bibliothèque v1.0</p>
        </div>
    </div>
</body>
</html>
EOF

    echo -e "${GREEN}✓ Export HTML créé avec succès!${NC}"
    echo ""
    echo "Fichier: $fichier_export"
    echo ""
    echo "Ouvrir le fichier maintenant? (o/n)"
    read -p "> " ouvrir
    
    if [[ "$ouvrir" == "o" ]] || [[ "$ouvrir" == "O" ]]; then
        if command -v xdg-open 2> /dev/null; then
            xdg-open "$fichier_export"
        elif command -v open &> /dev/null; then
            open "$fichier_export"
        else
            echo "Impossible d'ouvrir automatiquement le fichier."
        fi
    fi
    
    pause
}

# Export PDF
export_pdf() {
    clear
    echo -e "${CYAN}=== EXPORT PDF ===${NC}"
    echo ""
    
    echo "Étape 1/2 : Génération du rapport HTML..."
    local date_export=$(date +%Y%m%d_%H%M%S)

    # → Correction : récupérer le DERNIER fichier HTML généré
    local fichier_html=$(ls -t ${EXPORT_DIR}/*.html 2>/dev/null | head -n 1)

    local fichier_pdf="${EXPORT_DIR}/bibliotheque_${date_export}.pdf"
    
    if [[ ! -f "$fichier_html" ]]; then
        echo -e "${RED}✗ Aucun fichier HTML trouvé, génération...${NC}"
        export_html
        fichier_html=$(ls -t ${EXPORT_DIR}/*.html | head -n 1)
    fi
    
    echo -e "${GREEN}✓ HTML détecté : $fichier_html${NC}"
    echo ""
    echo "Étape 2/2 : Conversion en PDF..."
    echo ""
    
    local conversion_reussie=false
    
    # ────────────────────────────────────────────────
    # MÉTHODE 1 : weasyprint
    # ────────────────────────────────────────────────
    if command -v weasyprint &> /dev/null; then
        echo "→ Utilisation de WeasyPrint..."
        weasyprint "$fichier_html" "$fichier_pdf" &> /dev/null
        
        if [[ -f "$fichier_pdf" ]]; then
            conversion_reussie=true
            echo -e "${GREEN}✓ Conversion réussie avec WeasyPrint${NC}"
        fi

    elif command -v chromium-browser &> /dev/null; then
        echo "→ Utilisation de chromium-browser..."

        chromium-browser --headless --disable-gpu --no-sandbox \
                         --print-to-pdf="$fichier_pdf" \
                         "file://$fichier_html" &> /dev/null

        if [[ -f "$fichier_pdf" ]]; then
            conversion_reussie=true
            echo -e "${GREEN}✓ Conversion réussie avec chromium-browser${NC}"
        fi
        
    elif command -v google-chrome &> /dev/null; then
        echo "→ Utilisation de Google Chrome..."

        google-chrome --headless --disable-gpu --no-sandbox \
                      --print-to-pdf="$fichier_pdf" \
                      "file://$fichier_html" &> /dev/null

        if [[ -f "$fichier_pdf" ]]; then
            conversion_reussie=true
            echo -e "${GREEN}✓ Conversion réussie avec Google Chrome${NC}"
        fi

    # ────────────────────────────────────────────────
    # MÉTHODE 2 : wkhtmltopdf
    # ────────────────────────────────────────────────
    elif command -v wkhtmltopdf &> /dev/null; then
        echo "→ Utilisation de wkhtmltopdf..."
        wkhtmltopdf --quiet --enable-local-file-access \
                    --page-size A4 --margin-top 10 --margin-bottom 10 \
                    "$fichier_html" "$fichier_pdf" &> /dev/null
        
        if [[ -f "$fichier_pdf" ]]; then
            conversion_reussie=true
            echo -e "${GREEN}✓ Conversion réussie avec wkhtmltopdf${NC}"
        fi

    # ────────────────────────────────────────────────
    # MÉTHODE 3 : chromium
    # ────────────────────────────────────────────────
    elif command -v chromium &> /dev/null; then
        echo "→ Utilisation de Chromium..."
        chromium \
            --headless \
            --disable-gpu \
            --no-sandbox \
            --print-to-pdf="$fichier_pdf" \
            --print-to-pdf-no-header \
            --print-to-pdf-margins=0 \
            --print-to-pdf-page-size=A4 \
            --run-all-compositor-stages-before-draw \
            --virtual-time-budget=8000 \
            "file://$fichier_html" &> /dev/null


        if [[ -f "$fichier_pdf" ]]; then
            conversion_reussie=true
            echo -e "${GREEN}✓ Conversion réussie avec Chromium${NC}"
        fi
    fi

    echo ""
    
    # ────────────────────────────────────────────────
    # RÉSULTAT
    # ────────────────────────────────────────────────
    if [[ "$conversion_reussie" == true ]]; then
        local taille=$(du -h "$fichier_pdf" | cut -f1)
        echo "╔═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗"
        echo -e "║ ${GREEN}✓ EXPORT PDF RÉUSSI${NC}                                                                                                            ║"
        echo "╠═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣"
        echo "  Fichier HTML : $fichier_html"
        echo "  Fichier PDF  : $fichier_pdf"
        echo "  Taille       : $taille"
        echo "╚═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
        echo ""
        
        read -p "Ouvrir le PDF maintenant? (o/n): " ouvrir
        
        if [[ "$ouvrir" =~ ^[oO]$ ]]; then
            open "$fichier_pdf" &>/dev/null &
        fi
        
    else
        echo -e "${YELLOW}⚠️ Aucun outil de conversion PDF disponible${NC}"
        echo ""
        echo "HTML disponible ici:"
        echo "  $fichier_html"
    fi
    
    pause
}

################################################################################
# SAUVEGARDE ET RESTAURATION
################################################################################

# Backup automatique quotidien
backup_automatique() {
    local date_today=$(date +%Y-%m-%d)
    local backup_today="${BACKUP_DIR}/auto_${date_today}.tar.gz"
    
    # Vérifier si un backup existe déjà pour aujourd'hui
    if [[ ! -f "$backup_today" ]]; then
        tar -czf "$backup_today" -C "$DATA_DIR" . 2>/dev/null
        
        # Nettoyer les anciens backups (garder 30 jours)
        find "$BACKUP_DIR" -name "auto_*.tar.gz" -mtime +30 -delete 2>/dev/null
    fi
}

# Créer un backup manuel
creer_backup() {
    clear
    echo -e "${GREEN}=== CRÉER UNE SAUVEGARDE ===${NC}"
    echo ""
    
    local date_backup=$(date +%Y%m%d_%H%M%S)
    read -p "Nom du backup [manuel_${date_backup}]: " nom_backup
    
    [[ -z "$nom_backup" ]] && nom_backup="manuel_${date_backup}"
    
    local fichier_backup="${BACKUP_DIR}/${nom_backup}.tar.gz"
    
    echo ""
    echo "Création du backup..."
    
    if tar -czf "$fichier_backup" -C "$DATA_DIR" . 2>/dev/null; then
        local taille=$(du -h "$fichier_backup" | cut -f1)
        echo -e "${GREEN}✓ Backup créé avec succès!${NC}"
        echo ""
        echo "Fichier: $fichier_backup"
        echo "Taille:  $taille"
    else
        echo -e "${RED}✗ Erreur lors de la création du backup!${NC}"
    fi
    
    pause
}

# Lister les backups
lister_backups() {
    clear
    echo -e "${CYAN}=== LISTE DES SAUVEGARDES ===${NC}"
    echo ""
    
    if [[ ! -d "$BACKUP_DIR" ]] || [[ -z "$(ls -A $BACKUP_DIR 2>/dev/null)" ]]; then
        echo "Aucune sauvegarde disponible."
        pause
        return
    fi
    
    printf "%-40s %-12s %-15s\n" "Nom" "Taille" "Date"
    echo "───────────────────────────────────────────────────────────────────"
    
    ls -lh "$BACKUP_DIR"/*.tar.gz 2>/dev/null | while read -r perm links owner group size month day time file; do
        local nom=$(basename "$file")
        printf "%-40s %-12s %-15s\n" "$nom" "$size" "$month $day $time"
    done
    
    echo ""
    pause
}

# Restaurer un backup
restaurer_backup() {
    clear
    echo -e "${YELLOW}=== RESTAURER UNE SAUVEGARDE ===${NC}"
    echo ""
    
    lister_backups
    
    echo ""
    read -p "Nom du fichier de backup (sans .tar.gz): " nom_backup
    
    local fichier_backup="${BACKUP_DIR}/${nom_backup}.tar.gz"
    
    if [[ ! -f "$fichier_backup" ]]; then
        echo -e "${RED}✗ Backup non trouvé!${NC}"
        pause
        return
    fi
    
    echo ""
    echo -e "${RED}ATTENTION: Cette action va écraser les données actuelles!${NC}"
    read -p "Êtes-vous sûr de vouloir continuer? (o/n): " confirm
    
    if [[ "$confirm" != "o" ]] && [[ "$confirm" != "O" ]]; then
        echo "Restauration annulée."
        pause
        return
    fi
    
    # Créer un backup de sécurité avant restauration
    local backup_securite="${BACKUP_DIR}/avant_restauration_$(date +%Y%m%d_%H%M%S).tar.gz"
    tar -czf "$backup_securite" -C "$DATA_DIR" . 2>/dev/null
    
    # Restaurer le backup
    rm -rf "${DATA_DIR:?}"/*
    tar -xzf "$fichier_backup" -C "$DATA_DIR" 2>/dev/null
    
    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}✓ Backup restauré avec succès!${NC}"
        echo ""
        echo "Un backup de sécurité a été créé: $backup_securite"
    else
        echo -e "${RED}✗ Erreur lors de la restauration!${NC}"
    fi
    
    pause
}

# Supprimer un backup
supprimer_backup() {
    clear
    echo -e "${RED}=== SUPPRIMER UNE SAUVEGARDE ===${NC}"
    echo ""
    
    lister_backups
    
    echo ""
    read -p "Nom du fichier de backup à supprimer (sans .tar.gz): " nom_backup
    
    local fichier_backup="${BACKUP_DIR}/${nom_backup}.tar.gz"
    
    if [[ ! -f "$fichier_backup" ]]; then
        echo -e "${RED}✗ Backup non trouvé!${NC}"
        pause
        return
    fi
    
    echo ""
    read -p "Êtes-vous sûr de vouloir supprimer ce backup? (o/n): " confirm
    
    if [[ "$confirm" == "o" ]] || [[ "$confirm" == "O" ]]; then
        rm -f "$fichier_backup"
        echo -e "${GREEN}✓ Backup supprimé avec succès!${NC}"
    else
        echo "Suppression annulée."
    fi
    
    pause
}