#!/bin/bash

################################################################################
# SYSTÈME DE GESTION DE BIBLIOTHÈQUE PERSONNELLE
# Version: 1.0
# Description: Gestion complète de livres avec fichiers plats
################################################################################

# Configuration des chemins
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_FUNCTIONS="${SCRIPT_DIR}/lib_functions.sh"
DATA_DIR="${SCRIPT_DIR}/data"
BACKUP_DIR="${SCRIPT_DIR}/backups"
EXPORT_DIR="${SCRIPT_DIR}/exports"

# Fichiers de données
LIVRES_FILE="${DATA_DIR}/livres.txt"
EMPRUNTS_FILE="${DATA_DIR}/emprunts.txt"

# Chargement de la bibliothèque de fonctions
if [[ ! -f "$LIB_FUNCTIONS" ]]; then
    echo "ERREUR: Fichier lib_functions.sh introuvable!"
    exit 1
fi
source "$LIB_FUNCTIONS"

################################################################################
# FONCTION PRINCIPALE - MENU
################################################################################
menu_principal() {
    while true; do
        clear
        dessiner_BU
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║           MENU PRINCIPAL - GESTION BIBLIOTHÈQUE            ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Gestion des livres                                     ║"
        echo "║  2. Recherche et filtres                                   ║"
        echo "║  3. Gestion des emprunts                                   ║"
        echo "║  4. Statistiques et rapports                               ║"
        echo "║  5. Sauvegarde et restauration                             ║"
        echo "║  0. Quitter                                                ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) menu_gestion_livres ;;
            2) menu_recherche ;;
            3) menu_emprunts ;;
            4) menu_statistiques ;;
            5) menu_backup ;;
            0)
                echo ""
                echo "Merci d'avoir utilisé le système de gestion de bibliothèque!"
                exit 0
                ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}

################################################################################
# MENU GESTION DES LIVRES
################################################################################
menu_gestion_livres() {
    while true; do
        clear
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║                   GESTION DES LIVRES                       ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Ajouter un livre                                       ║"
        echo "║  2. Modifier un livre                                      ║"
        echo "║  3. Supprimer un livre                                     ║"
        echo "║  4. Lister tous les livres                                 ║"
        echo "║  5. Afficher un livre par ID                               ║"
        echo "║  0. Retour au menu principal                               ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) ajouter_livre ;;
            2) modifier_livre ;;
            3) supprimer_livre ;;
            4) lister_livres ;;
            5) afficher_livre_par_id ;;
            0) return ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}



################################################################################
# MENU RECHERCHE ET FILTRES
################################################################################
menu_recherche() {
    while true; do
        clear
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║                  RECHERCHE ET FILTRES                      ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Rechercher par titre                                   ║"
        echo "║  2. Rechercher par auteur                                  ║"
        echo "║  3. Filtrer par genre                                      ║"
        echo "║  4. Filtrer par année                                      ║"
        echo "║  5. Recherche avancée (multi-critères)                     ║"
        echo "║  0. Retour au menu principal                               ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) rechercher_par_titre ;;
            2) rechercher_par_auteur ;;
            3) filtrer_par_genre ;;
            4) filtrer_par_annee ;;
            5) recherche_avancee ;;
            0) return ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}

################################################################################
# MENU EMPRUNTS
################################################################################
menu_emprunts() {
    while true; do
        clear
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║                 GESTION DES EMPRUNTS                       ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Emprunter un livre                                     ║"
        echo "║  2. Retourner un livre                                     ║"
        echo "║  3. Lister les livres empruntés                            ║"
        echo "║  4. Vérifier les retards                                   ║"
        echo "║  5. Historique des emprunts                                ║"
        echo "║  0. Retour au menu principal                               ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) emprunter_livre ;;
            2) retourner_livre ;;
            3) lister_emprunts ;;
            4) verifier_retards ;;
            5) historique_emprunts ;;
            0) return ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}

################################################################################
# MENU STATISTIQUES
################################################################################
menu_statistiques() {
    while true; do
        clear
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║               STATISTIQUES ET RAPPORTS                     ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Statistiques globales                                  ║"
        echo "║  2. Répartition par genre                                  ║"
        echo "║  3. Top 5 auteurs                                          ║"
        echo "║  4. Livres par décennie                                    ║"
        echo "║  5. Export HTML                                            ║"
        echo "║  6. Export PDF (via HTML)                                  ║"
        echo "║  0. Retour au menu principal                               ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) statistiques_globales ;;
            2) repartition_genres ;;
            3) top_auteurs ;;
            4) livres_par_decennie ;;
            5) export_html ;;
            6) export_pdf ;;
            0) return ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}

################################################################################
# MENU BACKUP
################################################################################
menu_backup() {
    while true; do
        clear
        afficher_banniere
        echo ""
        echo "╔════════════════════════════════════════════════════════════╗"
        echo "║             SAUVEGARDE ET RESTAURATION                     ║"
        echo "╠════════════════════════════════════════════════════════════╣"
        echo "║  1. Créer une sauvegarde manuelle                          ║"
        echo "║  2. Lister les sauvegardes                                 ║"
        echo "║  3. Restaurer une sauvegarde                               ║"
        echo "║  4. Supprimer une sauvegarde                               ║"
        echo "║  0. Retour au menu principal                               ║"
        echo "╚════════════════════════════════════════════════════════════╝"
        echo ""

        read -p "Votre choix: " choix

        case $choix in
            1) creer_backup ;;
            2) lister_backups ;;
            3) restaurer_backup ;;
            4) supprimer_backup ;;
            0) return ;;
            *)
                echo "Choix invalide!"
                pause
                ;;
        esac
    done
}


################################################################################
# INITIALISATION ET DÉMARRAGE
################################################################################

# Vérification et création de l'arborescence
verifier_structure

# Backup automatique quotidien
backup_automatique

echo "Bienvenue dans le système de gestion de bibliothèque personnelle"
menu_principal